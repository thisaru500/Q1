package priority_test_1;

import org.testng.annotations.Test;

public class PriorityTest {

    @Test(priority = -2)
    public void signUp() {
        System.out.println("1. signUp()");
    }

    @Test(priority = 0)
    public void login() {
        System.out.println("2. login()");
    }

    @Test(priority = -1)
    public void searchProduct() {
        System.out.println("3. searchProduct()");
    }

    @Test(priority = 2)
    public void addToCart() {
        System.out.println("4. addToCart()");
    }

    @Test(priority = 3)
    public void signOut() {
        System.out.println("5. signOut()");
    }
}


/*
 	Priority Value	|	Execution Order
 	---------------------------------------------------------
	Not specified	|	Alphabetical
	Positive int	|	Lowest to highest
	Negative int	|	Executed before 0 and positive values
 */

