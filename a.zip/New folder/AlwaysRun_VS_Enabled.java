package enabled_5;

import org.testng.annotations.Test;

public class AlwaysRun_VS_Enabled {
	@Test(alwaysRun = true, enabled = false)
	public void a() {
	    System.out.println("Method a");
	}
}

/* 
	enabled = false overrides all other attributes.
	Even if you add priority, dependsOnMethods, or alwaysRun, the method won’t run.
 */