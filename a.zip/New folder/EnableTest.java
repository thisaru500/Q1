package enabled_5;

import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Test;

public class EnableTest {
	// Disabled test – will be skipped
    @Test(enabled = false)
    public void a() {
        System.out.println("Method a (disabled)");
    }

    @Test
    public void b() {
        System.out.println("Method b");
        throw new NoSuchElementException("Simulated exception in b()");
    }

    // Depends on 'b', but always runs even if 'b' fails
    @Test(dependsOnMethods = "b", alwaysRun = true)
    public void c() {
        System.out.println("Method c (always runs even if b fails)");
    }
}
