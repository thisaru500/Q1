package invocation_count_invocation_time_out_3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class InvocationCount_InvocationTimeOut_Test {
  
	// This test opens Google in Chrome 3 times
    @Test(invocationCount = 3)
    public void openGoogleMultipleTimes() {
    	
        System.setProperty("webdriver.chrome.driver", "D://Uni//3_2//Selenium//chromedriver-win64//chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.navigate().to("https://www.google.com");
        
        driver.manage().window().maximize();

        System.out.println("Opened Google");

        driver.quit();
    }

    // This test opens Google 3 times and must complete all in 5 seconds
    @Test(invocationCount = 3, invocationTimeOut = 5000)
    public void openGoogleWithTimeout() {
    	
        System.setProperty("webdriver.chrome.driver", "D://Uni//3_2//Selenium//chromedriver-win64//chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.navigate().to("https://www.google.com");
        
        driver.manage().window().maximize();

        System.out.println("Opened Google with timeout");

        driver.quit();
    }
}

/*
	invocationCount = 3			->	Test runs 3 times (opens and closes Chrome 3 times)
	invocationTimeOut = 5000	->	All runs must complete in 5 seconds
*/
