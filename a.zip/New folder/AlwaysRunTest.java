package always_run_4;

import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Test;

public class AlwaysRunTest {
  
	@Test
    public void a() {
        System.out.println("Method a");
    }

    @Test
    public void b() {
        System.out.println("Method b");
        throw new NoSuchElementException("Simulated exception in b()");
    }

    // Even if method b() fails, this will still run
    @Test(dependsOnMethods = "b", alwaysRun = true)
    public void c() {
        System.out.println("Method c (alwaysRun = true)");
    }
}

/* 
 	alwaysRun default value is false
 	dependsOnMethods + alwaysRun=true  ->	Forces the method to run even if dependency fails
 */