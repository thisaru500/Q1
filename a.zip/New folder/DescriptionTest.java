package description_6;

import org.testng.annotations.Test;

public class DescriptionTest {
	
	@Test(description = "This is a sample TestNG Test")
    public void a() {
        System.out.println("Method a");
    }
}

/*
	description	-> Describes what the test method does
	default value is "".(empty)
 */