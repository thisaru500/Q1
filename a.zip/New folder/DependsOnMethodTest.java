package depends_on_method_2;

import org.testng.annotations.Test;

public class DependsOnMethodTest {

    @Test(dependsOnMethods = "methodB")
    public void methodA() {
        System.out.println("Executing method A after B");
    }

    @Test
    public void methodB() {
        System.out.println("Executing method B");
    }

    @Test
    public void methodC() {
        throw new RuntimeException("Forcing failure in method C");
    }

    @Test(dependsOnMethods = "methodC")
    public void methodD() {
        System.out.println("Executing method D after C");
    }
}
