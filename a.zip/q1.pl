membership(X, [X|_]) :- !.
membership(X, [_|T]) :- membership(X, T).

age(X, Y, A) :- person(_, X, dob(_, _, Year)), A is Y - Year.

ageWithin(X1, X2, Y) :- 
		husband(X1, X2, _),
		person(_, X1, dob(_, _, Year1)), 
		person(_, X2, dob(_, _, Year2)), 
		Year1 < Year2,
		Y3 is Year2 - Year1,
		Y =< Y3.
		
ageDiference(X1, X2, Y) :- 
		person(male, X1, dob(_, _, Year1)), 
		person(female, X2, dob(_, _, Year2)),
		\+ husband(_, X1, _),
		\+ husband(_, X2, _),
		Year1 < Year2,
		Y3 is Year2 - Year1,
		Y =< Y3.
		
siblings(X, Y) :- 
		father(_, Children),
		membership(X, Children),
		membership(Y, Children),
		X \= Y.

mother(X, Y) :- 
		person(female, X, _), 
		husband(Father, X, _),
		father(Father, Children),
		membership(Y, Children).
		
marriedFemales(X, Y) :-
		husband(_, X, dom(_, _, Year)),
		Y > Year.
		
ancestor(X, Y) :- 
		person(male, X, _),
		father(Father, Children1),
		membership(Y, Children1),
		father(X, Children2),
		membership(Father, Children2).

parent(X, Y) :- mother(X, Y); father(X, Y).
cousin(X, Y) :- 
		parent(Z, X), parent(W, Y), 
		father(_, Children),
		membership(Z, Children),
		membership(W, Children),
		Z \= W.
		
elder_than(X, Y) :-
		siblings(X, Y),
		person(_, X, dob(_, _, Year1)),
		person(_, Y, dob(_, _, Year2)),
		Year1 < Year2.


% Pascal Tree
element(R, 1, 1) :- R > 0, !.
element(R, R, 1) :- R > 0, !.

% The Nth element is the sum of (N-1)th and Nth elements in the previous row.
element(R, N, Value) :- 
				R > 0, N > 1, N < R,   % Ensure N is between 1 and R
				R1 is R - 1,
				N1 is N - 1,
				N2 is N,
				element(R1, N1, Value1),
				element(R1, N2, Value2),
				Value is Value1 + Value2.

% Print all elements in a row
% Stop printing when N exceeds R
printElement(R, N) :- N > R, !.  
printElement(R, N) :- 
				element(R, N, Value), 
				write(Value), 
				tab(1),
				N1 is N + 1, 
				printElement(R, N1).

% Print all rows up to Max
% Stop printing when R exceeds Max
linee(R, Max) :- R > Max, !.  
linee(R, Max) :- 
				tab(40 - R),
				printElement(R, 1), nl, 
				R1 is R + 1, 
				linee(R1, Max).

pascal(R) :- R > 0, linee(1, R).


% Tower of Hanoi 
move(1, S, I, T) :- write(S), write(' to '), write(T), nl, !. 
move(N, S, I, T) :- 
		N > 1, M is N-1, 
		move(M, S, T, I), 
		move(1, S, I, T), 
		move(M, I, S, T). 
		
		
% Tower of Hanoi - second method
move1(1, Source, Target, _) :- write('Move top disk from '), write(Source), write( ' to '), write(Target), nl.

move1(N, Source, Target, Intermediate) :-
		N>1, N1 is N-1,

		% Step 1: Moves N-1 disks from the Source stem to the Intermediate stem, using the Target stem as auxiliary stem
		move1(N1, Source, Intermediate, Target),

		% Step 2: Moves the largest disk(N) from the Source stem to the Target stem
		move1(1, Source, Target, _),

		% Step 3: Moves the N-1 disks from the Intermediate stem to the Target stem, using the Source stem as auxiliary stem
		move1(N1, Intermediate, Target, Source), !.

towerOfHanoi(N) :- move1(N, 'Source', 'Target', 'Intermediate').


findGrade :- write('Enter marks : '), read(M), nl, grade(M).
grade(N) :- 
		N >= 80, !,  write('A');
		N >= 60, !, write('B'); 
		N >= 40, !, write('C'); 
		write('F').
		
multiTable :-
			write('Enter number : '), read(N),
			write('..up to? : '), read(M), nl,
			process(1, N, M).
process(I, N, M) :-
				write(I), write('*'), write(N), write(' = '), R is I*N, write(R), nl,
				I1 is I+1, I1=<M, process(I1, N, M).
			
			
gcd(X, 0, X) :- X > 0, !.
gcd(X, Y, G) :- Y > 0, !, X1 = Y, Y1 is X mod Y, gcd(X1, Y1, G).

lcm(X, Y, L) :- M = X * Y, gcd(X, Y, G), L is M // G.


% Merge two already sorted Lists
sortedmerge([], L, L) :- !. 
sortedmerge(L, [], L) :- !.  
sortedmerge([H1|T1], [H2|T2], [H1|T3]) :- H1 =< H2, sortedmerge(T1, [H2|T2], T3).
sortedmerge([H1|T1], [H2|T2], [H2|T3]) :- H1 > H2, sortedmerge([H1|T1], T2, T3).          % Continue merging the first list with the tail of the second list

% Divide a list L into two lists of equal lengths
divide(L, L1, L2) :-
    length(L, Len),
    HalfLen is Len // 2,  
    split_at(HalfLen, L, L1, L2).

split_at(0, L, [], L) :- !.  
split_at(N, [H|T], [H|L1], L2) :-
    N > 0,                  
    N1 is N - 1,            
    split_at(N1, T, L1, L2).



split(_, [], [], []) :- !. 		
split(X, [Y|T], [Y|Small], Big) :- X > Y, !, split(X, T, Small, Big).  
split(X, [Y|T], Small, [Y|Big]) :- split(X, T, Small, Big).  
/*
	| ?- split(4, [], Small, Big).
	Big = []
	Small = []

	| ?- split(2, [1,2,3,4], Small, Big).
	Big = [2,3,4]
	Small = [1]

	| ?- split(20, [1,12,23,34], Small, Big).
	Big = [23,34]
	Small = [1,12]
*/

% Quick sort 
qs([],[]). 
qs([X|T],SL):-
			split(X,T,Small,Big),
			qs(Small,SS),
			qs(Big,SB),
			conc(SS,[X|SB],SL).  


%MergeSort by divide and merge 
mergesort([], []) :- !. 
mergesort([X], [X]) :- !. 
mergesort(L, SL) :- 
				divide(L, L1, L2),
				mergesort(L1, SL1),
				mergesort(L2, SL2),
				merge(SL1, SL2, SL). 

divide([], [], []) :- !. 
divide([X], [X], []) :- !. 
divide([X,Y|T], [X|T1], [Y|T2]) :- divide(T, T1, T2). 

merge([], L, L) :- !. 
merge(L, [], L) :- !. 
merge([H1|T1], [H2|T2], [H1|T3]) :- H1 =< H2, merge(T1, [H2|T2], T3), !. 
merge([H1|T1], [H2|T2], [H2|T3]) :- H1 > H2, merge([H1|T1], T2, T3). 


% Insertion sort 
ins([], []) :- !.
ins([X|T], SL) :- 
			ins(T, ST), 
			insert(ST, X, SL).
			
insert([], X, [X]) :- !.
insert([Y|SL], X, [Y|SL1]) :- X>Y, !, insert(SL, X, SL1). 
insert([Y|SL], X, [X, Y|SL]).


%Bubble Sort 
bbs(L,SL):-swap(L,L1),!,bbs(L1,SL). 
bbs(S,S). 

swap([X,Y|R], [Y,X|R]) :- gt(X,Y). 
swap([Z|R], [Z|R1]) :- swap(R, R1). 
gt(X, Y) :- X > Y. 



count_to_10(X) :- 
			X =< 10, write(X), nl,
			X1 is X+1, count_to_10(X1).

/*			
	between() is a built-in predicate used to generate integers within a specified range => between(Low, High, X)
		?- between(1, 5, X).
		X = 1 ;
		X = 2 ;
		X = 3 ;
		X = 4 ;
		X = 5.
*/
% All pairs of integers between 1 and 3 that sum up to 4
find_pairs :-
    between(1, 3, X),
    between(1, 3, Y),
    X + Y =:= 4,
    write((X, Y)), nl, fail.		% fail forces Prolog to backtrack and find all possible solutions.(no need to give ; for further matches)

isGreater(X, Y) :- 
	X =:= Y, !, write('Both are equal'); 
	X > Y, !, write('Largest number is '), write(X); 
	write('Largest number is '), write(Y).
	
member1(X, [X|_]) :- !.
member1(X, [_|T]) :- member1(X, T).

length1([], 0) :- !.
length1([_|T], L) :- length1(T, L1), L is L1 + 1.

delete1([X], X, []) :- !.
delete1([X|T], X, T) :- !.
delete1([Y|T1], X, [Y|T2]) :- delete1(T1, X, T2).

%conc(L1, L2, AL).
conc([], L, L) :- !.
conc([H1|T1], L2, [H1|T3]) :- conc(T1, L2, T3).

% Append into List (Same to addBegin())
append1(X, L, L) :- member1(X, L), !.		
append1(X, L, [X|L]).

% Add an element to a list
addBegin(L, X, [X|L]) :- !.		% OR addBegin(L, X, AL) :- conc([X], L, AL).
addEnd([H|T1], X, [H|T2]) :- addEnd(T1, X, T2).		% OR addEnd(L, X, AL) :- conc(L, [X], AL).

% Insert into List: insert(L, X, R), insert X into L in all possible positions
% We can use list_delete(R, X, L), so delete X from R and make new list L. 

delete2([X], X, []).
delete2([X|T], X, T).
delete2([Y|T1], X, [Y|T2]) :- delete2(T1, X, T2). 
insert(L, X, R) :- delete2(R, X, L).	

% Shift Operation: first element is moved to the end, and the other elements shift one position to the left.
conc1([], L, L).  
conc1([X1|T1], L2, [X1|T3]) :- conc1(T1, L2, T3).
shift([H|T], SL) :- conc1(T, [H],SL). 

% Order Operation:  checks whether a list is ordered or not. So if L = [1,2,3,4], then the result will be true.
order([X]) :- !.
order([H1,H2|T]) :- H1 =< H2, order([H2|T]).

% Subset Finding Operation:
subset([], []) :- !.
subset([H|T], [H|Subset]) :- subset(T, Subset).		
subset([H|T], Subset) :- subset(T, Subset).			

sum([], 0) :- !.
sum([H|T], Sum) :- sum(T, SumTail), Sum is H + SumTail.

mean(L, M) :- sum(L, S), len(L, Len), Len>0, !, M is S/Len.
mean(_, _) :- write('Null List').

reverse1([], []) :- !.
reverse1([H|T], RL) :- reverse1(T, RT), append(RT, [H], RL).

palindrome(L) :- 
		reverse1(L, RL), L = RL, !, nl, 
		write('Given word is a palindrome.');
		write('Given word is not a palindrome.').


smallest([X], X) :- !. 
smallest([H|T], X):- smallest(T, X1), (H < X1, !, X is H; X is X1).  

largest([X], X) :- !. 
largest([H|T], X):- largest(T, X1), (H > X1, !, X is H; X is X1).  

aOL([X], [X]) :- !. 
aOL(L, OL) :- smallest(L, X), delete1(L, X, L1), aOL(L1, L2), OL = [X|L2]. 
 
dOL(L, DL) :- aOL(L, OL), reverse(OL, DL).



/*
	% Define a point structure with x and y coordinates
	point(X, Y).

	% Define a line segment structure between two points
	segment(point(X1,Y1), point(X2,Y2)).

	% Define a triangle with three points
	triangle(point(X1,Y1), point(X2,Y2), point(X3,Y3)).

	% Define a quadrilateral with four points, ordered clockwise
	quadrilateral(point(X1,Y1), point(X2,Y2), point(X3,Y3), point(X4,Y4)).
*/

% (a) Check lines are parallel
gradient(point(X1,Y1), point(X2,Y2), M) :- M is (Y2-Y1)/(X2-X1).

parallel(point(X1,Y1), point(X2,Y2), point(X3,Y3), point(X4,Y4)) :- 
		gradient(point(X1,Y1), point(X2,Y2), M1), 
		gradient(point(X3,Y3), point(X4,Y4), M2), 
		M1 =:= M2.

% (b) Check lines are perpendicular
perpendicular(point(X1,Y1), point(X2,Y2), point(X3,Y3), point(X4,Y4)) :- 
		gradient(point(X1,Y1), point(X2,Y2), M1), 
		gradient(point(X3,Y3), point(X4,Y4), M2), 
		M1*M2 =:= -1.

% (c) Length of a line segment
len(point(X1, Y1), point(X2, Y2), L) :- 
		L is sqrt((X2 - X1) ** 2 + (Y2 - Y1) ** 2).

% (d) Area of a triangle
area1(point(X1, Y1), point(X2, Y2), point(X3, Y3), A) :- 
		A is abs(0.5 * (X1 * (Y2 - Y3) + X2 * (Y3 - Y1) + X3 * (Y1 - Y2))).

% (e) Check whether a quadrilateral is a parallelogram - opposite sides should equal
isParallelogram(point(X1, Y1), point(X2, Y2), point(X3, Y3), point(X4, Y4)) :- 
		len(point(X1, Y1), point(X2, Y2), L1),
		len(point(X3, Y3), point(X4, Y4), L2),
		len(point(X2, Y2), point(X3, Y3), L3),
		len(point(X4, Y4), point(X1, Y1), L4),
		L1 =:= L2, L3 =:= L4.

% (f)  Check whether a quadrilateral is a square
isSquare(point(X1, Y1), point(X2, Y2), point(X3, Y3), point(X4, Y4)) :- 
		len(point(X1, Y1), point(X2, Y2), L1),
		len(point(X2, Y2), point(X3, Y3), L2),
		len(point(X3, Y3), point(X4, Y4), L3),
		len(point(X4, Y4), point(X1, Y1), L4),
		len(point(X1, Y1), point(X3, Y3), D1), % Diagonal 1
		len(point(X2, Y2), point(X4, Y4), D2), % Diagonal 2
		L1 =:= L2, L2 =:= L3, L3 =:= L4, D1 =:= D2.

horizontal(point(_, Y1), point(_, Y2)) :- Y1 =:= Y2.
vertical(point(X1, _), point(X2, _)) :- X1 =:= X2.

addComplex(complex(R1, I1), complex(R2, I2), complex(RA, IA)) :-RA is R1 + R2, IA is I1 + I2.

fac(0, 1) :- !.
fac(N, F) :- N > 0, !, N1 is N-1, fac(N1, F1), F is N*F1; write('Enter positive number').

permutation(N, R, P) :- fac(N, F1), fac(N-R, F2), P is F1 // F2.
combination(N, R, C) :- permutation(N, R, P), fac(R, F), C is P // F.

isEven(N) :- X is N mod 2, X =:= 0, !, write('Even'); write('Odd').



% ----------------------------------------------------- Star Patterns ---------------------------------------------------------

printStarLine(0) :- !.					
printStarLine(N) :- N > 0, write('* '), N1 is N-1, printStarLine(N1).

printStarsMatrix :- 
    write('Number of rows: '), read(R),
    write('Number of columns: '), read(C),
    print_rows(R, C).

print_rows(0, _) :- !.  
print_rows(R, C) :-
				print_columns(C), nl,                     
				R1 is R - 1, print_rows(R1, C).      

print_columns(0) :- !.      
print_columns(C) :- write('* '), C1 is C - 1, print_columns(C1).  


/* 
	* * * * 
	* * * 
	* * 
	*
*/
printStarLine1(0) :- !. 
printStarLine1(N) :- write('* '), N1 is N-1, printStarLine1(N1).

printPattern1(0) :- !.    
printPattern1(N) :- 
				tab(80), printStarLine1(N), nl,  
				N1 is N-1, printPattern1(N1).
	
/* 
	* * * * 
	  * * * 
	    * * 
	      *
*/
printStarLine2(0) :- !.
printStarLine2(N) :- write('*'), N1 is N - 1, printStarLine2(N1).    

printPattern2(N) :-
				N > 0, R is 50 - N, tab(R), printStarLine2(N), nl,
				N1 is N - 1, printPattern2(N1).


/* 
	*
	* *
	* * *
	* * * *
*/
printStarLine3(0) :- !.
printStarLine3(N) :- write('* '), N1 is N - 1, printStarLine3(N1).

printPattern3(L, M) :- L > M, !.
printPattern3(L, M) :-
    L > 0, printStarLine3(L), nl, 
    L1 is L + 1, printPattern3(L1, M).


/* 
	* * * * 
	 * * * 			Same pattern 2 code with write('* ') => this extra space moves the row towards right more & give the pattern
	  * * 			Inverted pascal triangle
	   * 
*/
printStarLine4(0) :- !.
printStarLine4(N) :- write('* '), N1 is N - 1, printStarLine4(N1).    

printPattern4(N) :-
				N > 0, R is 50 - N, tab(R), printStarLine4(N), nl,
				N1 is N - 1, printPattern4(N1).
	

/* 
	   * 
	  * * 			Pascal Triangle , similar to pattern 3
	 * * * 			(Nth row contains N no. of elements)
	* * * * 
*/
printStarLine5(0) :- !.
printStarLine5(N) :- write('* '), N1 is N - 1, printStarLine5(N1).    

printPattern5(L, M) :-
				L > 0, L =< M, R is 50 - L, tab(R), printStarLine5(L), nl,
				L1 is L + 1, printPattern5(L1, M).


/* 
	   *
	  ***			No. of elements in a row(R) = 2*R - 1
	 *****
	*******
*/

printStarLine6(0) :- !.
printStarLine6(N) :- write('*'), N1 is N - 1, printStarLine6(N1).
				
printPattern6(S, L, M) :-
				L =< M, SS is 50 - S, tab(SS), N is 2*L - 1, printStarLine6(N), nl,
				L1 is L + 1, 
				SS1 is S + 1, 
				printPattern6(SS1, L1, M). 
/*
S: Starting position or space count (how many spaces before starting a row, 50-spaces).
L: Starting row number in the pattern.
M: Ending row number in the pattern.
*/


/*
	*******
	 *****			
	  ***
	   *
*/

printStarLine7(0) :- !.
printStarLine7(N) :- N > 0, write('*'), N1 is N - 1, printStarLine7(N1).

printPattern7(S, L, M) :-
    L =< M, SS is 50 - S, tab(SS), 
	N is 2 * (M - L + 1) - 1, % Calculate the number of stars to print (decreasing by 2 each row)
    printStarLine7(N), nl,
    L1 is L + 1, 
	SS1 is S - 1,
    printPattern7(SS1, L1, M). 
/*
S: Starting position or space count (how many spaces before starting a row, 50-spaces).
L: Starting row number in the pattern.
M: Ending row number in the pattern.
(So number of rows is M-L)
*/
