% Base case: Move a single disk directly from Source to Target
move(1, Source, _, Target) :- 
    write('Move disk from '), 
    write(Source), 
    write(' to '), 
    write(Target), 
    nl.

% Recursive case: Move N disks from Source to Target using Intermediate as a helper
move(N, Source, Intermediate, Target) :-
    N > 1,
    M is N - 1,                           % Reduce the problem to (N-1) disks
    move(M, Source, Target, Intermediate), % Step 1: Move (N-1) disks from Source to Intermediate
    move(1, Source, _, Target),            % Step 2: Move the largest disk from Source to Target
    move(M, Intermediate, Source, Target). % Step 3: Move (N-1) disks from Intermediate to Target
