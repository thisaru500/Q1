%If-Then-Else statement
	gt(X,Y) :- X>Y,write('X is greater or equal').
	gt(X,Y) :- X<Y,write('X is smaller').
	
%If-Elif-Else statement
	gte(X,Y) :- X>Y,write('X is greater').
	gte(X,Y) :- X=:=Y,write('X and Y are same').
	gte(X,Y) :- X<Y,write('X is smaller').