multi :- write('Enter the N value: '), read(N),
		 write('Enter the M value: '),read(M),nl,
		 process(1,N,M).
		
process(I,N,M) :- write(I),write(' * '),write(N),write(' = '),R is I*N, write(R),nl,
				  I1 is I+1, I1=<M, 
				  process(I1,N,M).
			