%To provided the reveresed list RL of a given list L 
reversedList(L,RL):-reverse(L,RL).

% To verify a given word is a palindrome
palindrome(L):-reversedList(L,RL),L=RL,!,nl,write('Given word is a 
palindrome.');write('Given word is not a palindrome.').

%To find X which is smallest element in the list L
smallest(X,[X1]):-X is X1,!.
smallest(X,L):- L = [X1|L1], smallest(X2,L1),X1 < X2,!,X is X1.
smallest(X,L):- L = [X1|L1], smallest(X2,L1),X1 >= X2,X is X2.

%To find the length (Len) of a given List
length1([],0):-!.
length1(L,Len):- L=[_|L1], length1(L1,N1), Len is N1 +1.

%Concatenation of L1 and L2 is given by L3
conc([],L,L).
conc([X|L1],L2,[X|L3]):-conc(L1,L2,L3).

% delete the element X from a List L and returen the balanced elements in L.
del(X,[X|L],L).
del(X,[Y|T],[Y|T1]):-del(X,T,T1).

%Acending Ordered List (aOL)of a given list L is given by OL.
aOL([X],[X]):-!.
aOL(L,OL):-smallest(X,L),del(X,L,L1),aOL(L1,L2),OL=[X|L2].

%Decending Ordered List (dOL) of a given list L is given by DL.
dOL(L,DL):-aOL(L,OL),reverse(OL,DL).
%Tower of Hanoi
move(1,S,I,T):-write(S),write(' to '),write(T),nl,!.
move(N,S,I,T):-N>1,M is N-1,move(M,S,T,I),move(1,S,I,T),move(M,I,S,T).

%Bubble Sort
bbs(L,SL):-swap(L,L1),!,bbs(L1,SL).
bbs(S,S).
swap([X,Y|R],[Y,X|R]):-gt(X,Y).
swap([Z|R],[Z|R1]):-swap(R,R1).
gt(X,Y):-X>Y.

% Insertion sort
ins([],[]).
ins([X|T],SL):-ins(T,ST),insert(X,ST,SL).
insert(X,[Y|SL],[Y|SL1]):-gt(X,Y),!,insert(X,SL,SL1).
insert(X,SL,[X|SL]).

% Quick sort
qs([],[]).
qs([X|T],SL):-split(X,T,Small,Big),qs(Small,SS),qs(Big,SB),conc(SS,[X|SB],SL). 
split(X,[],[],[]).
split(X,[Y|T],[Y|Small],Big):- gt(X,Y),!,split(X,T,Small,Big).
split(X,[Y|T],Small,[Y|Big]):-split(X,T,Small,Big).

%MergeSort by divide and merge
mergesort([],[]):-!.
mergesort([X],[X]):-!.
mergesort(L,SL):-
divide(L,L1,L2),mergesort(L1,SL1),mergesort(L2,SL2),merge(SL1,SL2,SL).
divide([],[],[]):-!.
divide([X],[X],[]):-!.
divide([X,Y|L],[X|L1],[Y|L2]):-divide(L,L1,L2).
merge([],L,L):-!.
merge(L,[],L):-!.
merge([X|R1],[Y|R2],[X|R3]):-X<Y,!,merge(R1,[Y|R2],R3).
merge(L1,[Y|R2],[Y|R3]):-merge(L1,R2,R3)