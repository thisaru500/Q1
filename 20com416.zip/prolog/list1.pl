list_member(X, [X|_]).  % Base case: X is the head of the list.
list_member(X, [_|TAIL]) :- list_member(X, TAIL).  % Recursive case: check the tail of the list.
