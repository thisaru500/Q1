list_subset([],[]). 
list_subset([Head|Tail],[Head|Subset]) :- list_subset(Tail,Subset). 
list_subset([Head|Tail],Subset) :- list_subset(Tail,Subset).
