calc:- X is 100+200,write('100+200 is '),write(X),nl,
Y is 400-150,write('400 - 150 is '),write(Y),nl,
Z is 10*300,write('10*300 is '),write(Z),nl,
A is 100/30,write('100/30 is '),write(A),nl,
B is 100//30,write('100//30 is '),write(B),nl,
C is 100**2,write('100**2 is '),write(C),nl,
D is 100 mod 30,write('100mod30 is '),write(D),nl.